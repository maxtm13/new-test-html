const getConfig = require('./default');

module.exports = getConfig('footer', [
  {
    misMatchThreshold: 5,
  }
]);
